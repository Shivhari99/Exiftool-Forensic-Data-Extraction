// Template: Filtering a For Each String Array 1.txt

import java.lang.*;
import java.util.*;
import java.io.*;
import java.net.*;

public class Example226App extends Object
{
	private static final String  CONSTANT_1 = "Caithness Volume 1=NC02";
	private static final String HASH_REFERENCE = "dda4dbd8cae771249461db114df9a6b8";

	public static void main(String[] argStrings) throws Exception
	{
		String[] dayAbbreviations = {"Fri", "Sat", "Sun", "Tue"};
		
		String selected = "";
		String sep = "";
		
		for (String dayAbbreviation: dayAbbreviations)
		{
			System.err.println("dayAbbreviation: " + dayAbbreviation);
		
			if (!dayAbbreviation.contains("at"))
			{
				selected = selected + dayAbbreviation;
				sep = ", ";
			}
		}
		
		System.out.println(selected);
		
	}
}

