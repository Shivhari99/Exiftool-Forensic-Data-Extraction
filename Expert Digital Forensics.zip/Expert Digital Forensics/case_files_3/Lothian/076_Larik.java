// Template: Filtering a Variable-size String Collection 1.txt

import java.lang.*;
import java.util.*;
import java.io.*;
import java.net.*;

public class Example232App extends Object
{
	private static final String HASH_REFERENCE = "9f73f73e4de16d6ce00ea85d290ba872";

	public static void main(String[] argStrings) throws Exception
	{
		ArrayList<String> americanStates = new ArrayList<String>();
		
		Scanner scanner = new Scanner(new File("data.txt"));
		
		while (scanner.hasNextLine())
		{
			americanStates.add(scanner.nextLine());
		}
		
		scanner.close();
		
		for (int count = 0; count < americanStates.size(); count++)
		{
			if (americanStates.get(count).endsWith("rk"))
			{
				System.out.println(americanStates.get(count));
			}
		}
	}
}

