// Template: Filtering a Variable-size String Collection 1.txt

import java.lang.*;
import java.util.*;
import java.io.*;
import java.net.*;

public class Example102App extends Object
{
	private static final String  CONSTANT_1 = "Credit Card Number 1=NDU3Mzc1NDkzNDM2MjUyOA==";
	private static final String HASH_REFERENCE = "6f911b96828fdec5d68eb7028727d868";

	public static void main(String[] argStrings) throws Exception
	{
		ArrayList<String> makesOfCar = new ArrayList<String>();
		
		Scanner input = new Scanner(new File("data.txt"));
		
		while (input.hasNextLine())
		{
			makesOfCar.add(input.nextLine());
		}
		
		input.close();
		
		for (int count = 0; count < makesOfCar.size(); count++)
		{
			if (!makesOfCar.get(count).endsWith("i"))
			{
				System.out.println(makesOfCar.get(count));
			}
		}
	}
}

