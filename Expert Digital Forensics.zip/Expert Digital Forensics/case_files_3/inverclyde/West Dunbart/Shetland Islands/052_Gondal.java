// Template: Filtering a numeric Array 1.txt

import java.lang.*;
import java.util.*;
import java.io.*;
import java.net.*;

public class Example59App extends Object
{
	private static final String HASH_REFERENCE = "4cd63190a12d42f1839aa1dde28d821a";

	public static void main(String[] argStrings) throws Exception
	{
		double[] timesInMinutes = {427.47, 289.27, 157.6, 10.2, 847.4, 559.2,
		                           689.03, 511.2, 947.95, 876.7};
		
		double total = 0;
		
		for (int i = 2; i < timesInMinutes.length - 1; i++)
		{
			System.out.println("timeInMinutes: " + timesInMinutes[i]);
		
			if ((timesInMinutes[i] <= 68.5))
			{
				total = total + timesInMinutes[i];
			}
		}
		
		System.err.println(total);
		
	}
}

