// Template: Filtering a String Array 2.txt

import java.lang.*;
import java.util.*;
import java.io.*;
import java.net.*;

public class Example224App extends Object
{
	private static final String HASH_REFERENCE = "3f9452a0b8540ad9b298079a972e7395";

	public static void main(String[] argStrings) throws Exception
	{
		String[] countries = {"India", "Mexico", "Brazil", "Germany", "USA",
		                      "France", "Italy", "China", "Canada"};
		
		String selected = "";
		String sep = "";
		
		for (int i = 2; i < countries.length; i += 2)
		{
			System.err.println("i: " + i);
		
			if (countries[i].endsWith("ny"))
			{
				selected = selected + countries[i];
				sep = ", ";
			}
		}
		
		System.err.println(selected);
		
	}
}

