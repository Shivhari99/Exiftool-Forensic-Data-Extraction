// Template: Filtering a numeric Array 1.txt

import java.lang.*;
import java.util.*;
import java.io.*;
import java.net.*;

public class Example89App extends Object
{
	private static final String  CONSTANT_1 = "Secret 2 of 2=486172746d7574204d696368656c";
	private static final String HASH_REFERENCE = "0483cabdf47d722f7115f22c1b7fdd97";

	public static void main(String[] argStrings) throws Exception
	{
		int[] numbersOfDays = {239, 850, 297, 178, 711, 4};
		
		int sum = 0;
		
		for (int count = 0; count < numbersOfDays.length - 1; count++)
		{
			System.err.println("numberOfDays: " + numbersOfDays[count]);
		
			if (!(numbersOfDays[count] > 659))
			{
				sum = sum + numbersOfDays[count];
			}
		}
		
		System.err.println("Total: " + sum);
		
	}
}

